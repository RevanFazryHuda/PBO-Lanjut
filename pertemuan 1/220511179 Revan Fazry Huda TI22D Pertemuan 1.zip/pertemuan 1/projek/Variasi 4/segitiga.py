class segitiga:
    def __init__(self) :
        self.alas = None
        self.tinggi = None
        self.luas = None
        
    def Luas (self, alas, tinggi):
        self.alas = alas
        self.tinggi = tinggi
        self. luas = 1/2 * (self.alas * self.tinggi)
        return self.luas