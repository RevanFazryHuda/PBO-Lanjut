from segitiga import *

S = segitiga()
alas = input('Masukkan Nilai Alas\t: ')
tinggi = input('Masukkan Nilai Tinggi\t: ')
luas = S.Luas(int(alas),int(tinggi))

print('Alas\t: ',alas)
print('Tinggi\t: ',tinggi)
print('Luas\t: ',luas)