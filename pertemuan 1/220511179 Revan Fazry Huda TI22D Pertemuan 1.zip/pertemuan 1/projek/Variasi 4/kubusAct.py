from kubus import *    
    
K = kubus()
sisi = input('Masukkan Nilai Sisi\t: ')
volume = K.Volume(int(sisi))
luaspermukaan = K.LuasPermukaan(int(sisi))

print('Sisi\t: ',sisi)
print('Volume\t: ',volume)
print('Luas Permukaan\t: ',luaspermukaan)