from lingkaran import *
from math import pi

L = lingkaran()
JariJari = input('Masukkan Nilai Jari - Jari\t: ')
pi = pi
luas = L.Luas(float(pi),int(JariJari))

print('Jari - Jari\t: ',JariJari)
print('pi\t: ',pi)
print('Luas\t: ',luas)