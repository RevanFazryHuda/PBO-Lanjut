class kubus:
    def __init__(self):
        self._sisi = None
    
    @property    
    def sisi(self):
        return self._sisi
    
    @sisi.setter
    def sisi(self, value):
        self._sisi = value
        
    def volume(self):
        return self._sisi ** 3
    
    def luas_permukaan(self):
        return 6 * (self._sisi ** 2)

K = kubus()
s = input('Masukkan panjang sisi kubus: ')
K.sisi = int(s)
V = K.volume()
l = K.luas_permukaan()
print('Panjang Sisi:\t', s)
print('Volume Kubus:\t', V)
print('Luas Permukaan:\t', l)
