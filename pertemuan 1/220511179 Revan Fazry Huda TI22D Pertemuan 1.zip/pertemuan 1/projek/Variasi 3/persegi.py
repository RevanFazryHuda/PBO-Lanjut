class persegi:
    def __init__ (self):
        self._panjang = None
        self._lebar = None
    
    @property    
    def panjang(self):
        return self.panjang
    
    @panjang.setter
    def panjang(self, value):
        self._panjang = value
        
    @property    
    def lebar(self):
        return self.lebar
    
    @lebar.setter
    def lebar(self, value):
        self._lebar = value        
        
    def luas(self):
        return self._panjang * self._lebar
    
P = persegi()
panjang = input('Masukkan nilai Panjang\t: ')
lebar = input('Masukkan nilai lebar\t: ')
P.panjang = int(panjang)
P.lebar = int(lebar)
Luas = P.luas()
print('Panjang\t: ',panjang)
print('Lebar\t: ',lebar)
print('Luas\t: ',Luas)