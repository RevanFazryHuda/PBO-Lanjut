import math

class tabung:
    def __init__(self):
        self._jari_jari = None
        self._tinggi = None
    
    @property    
    def jari_jari(self):
        return self._jari_jari
    
    @jari_jari.setter
    def jari_jari(self, value):
        self._jari_jari = value
        
    @property    
    def tinggi(self):
        return self._tinggi
    
    @tinggi.setter
    def tinggi(self, value):
        self._tinggi = value        
        
    def volume(self):
        return math.pi * (self._jari_jari ** 2) * self._tinggi
    
    def luas_permukaan(self):
        return 2 * math.pi * self._jari_jari * (self._jari_jari + self._tinggi)

T = tabung()
r = input('Masukkan jari-jari tabung: ')
h = input('Masukkan tinggi tabung: ')
T.jari_jari = float(r)
T.tinggi = float(h)
V = T.volume()
A = T.luas_permukaan()
print('Jari-jari:\t', r)
print('Tinggi:\t\t', h)
print('Volume:\t\t', V)
print('Luas Permukaan:\t', A)
