class barang:
    def __init__(self, nama, kode) :
        self.nama = nama
        self.kode = kode
        
    def info(self):
        print(f'Nama\t: {self.nama}\nKode\t: {self.kode}')
        

brg = barang('Meja Billiard', 'B231PL')
brg.info()