class dosen:
    def __init__(self, nama, nidn) :
        self.nama = nama
        self.nidn = nidn
        
    def info(self):
        print(f'Nama\t: {self.nama}\nNIDN\t: {self.nidn}')
        

dsn = dosen('Rudi', '20319423')
dsn.info()