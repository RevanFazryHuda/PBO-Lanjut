class perumahan:
    def __init__(self, blok, kode) :
        self.blok = blok
        self.kode = kode
        
    def info(self):
        print(f'Blok\t: {self.blok}\nKode\t: {self.kode}')
        

rmh = perumahan('Mawar', 'MW22I')
rmh.info()