class segitiga:
    def __init__(self) :
        self.alas = None
        self.tinggi = None
        self.luas = None
        
    def Luas (self, alas, tinggi):
        self.alas = alas
        self.tinggi = tinggi
        self. luas = 1/2 * (self.alas * self.tinggi)
        return self.luas
    
S = segitiga()
alas = input('Masukkan Nilai Alas\t: ')
tinggi = input('Masukkan Nilai Tinggi\t: ')
luas = S.Luas(int(alas),int(tinggi))

print('Alas\t: ',alas)
print('Tinggi\t: ',tinggi)
print('Luas\t: ',luas)