class kubus:
    def __init__(self) :
        self.sisi = None
        self.volume = None
        self.luaspermukaan = None
        
    def Volume (self, sisi):
        self.sisi = sisi
        self. volume = (self.sisi)**3
        return self.volume
    
    def LuasPermukaan (self, sisi):
        self.sisi = sisi
        self. luaspermukaan = 6 * (self.sisi)**2
        return self.luaspermukaan    
    
K = kubus()
sisi = input('Masukkan Nilai Sisi\t: ')
volume = K.Volume(int(sisi))
luaspermukaan = K.LuasPermukaan(int(sisi))

print('Sisi\t: ',sisi)
print('Volume\t: ',volume)
print('Luas Permukaan\t: ',luaspermukaan)