from math import pi

class lingkaran:
    def __init__(self) :
        self.JariJari = None
        self.pi = pi
        self.luas = None
        
    def Luas (self, pi, JariJari):
        self.JariJari = JariJari
        self.pi = pi
        self. luas = pi * (self.JariJari)**2
        return self.luas
    
L = lingkaran()
JariJari = input('Masukkan Nilai Jari - Jari\t: ')
pi = pi
luas = L.Luas(float(pi),int(JariJari))

print('Jari - Jari\t: ',JariJari)
print('pi\t: ',pi)
print('Luas\t: ',luas)