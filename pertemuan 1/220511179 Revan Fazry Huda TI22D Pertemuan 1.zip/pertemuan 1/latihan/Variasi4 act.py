from Variasi4 import Balok

B = Balok()
P = input('Masukkan nilai Panjang :')
L = input('Masukkan nilai Lebar :')
T = input('Masukkan nilai Tinggi :')
V = B.Volume(int(P),int(L),int(T))
Lp = B.LuasPermukaan(int(P),int(L),int(T))


print('Panjang\t:',P)
print('Lebar\t:',L)
print('Tinggi\t:',T)
print('Volume\t:',V)
print('Luas Permukaan\t:',Lp)