class Balok:
    def __init__(self):
        self.panjang = None
        self.lebar = None
        self.tinggi = None
        self.volume = None
        self.luas = None
        
    def Volume(self, panjang, lebar, tinggi):
        self.panjang = panjang
        self.lebar = lebar
        self.tinggi = tinggi
        self.volume = self.panjang * self.lebar * self.tinggi
        return self.volume
    
    def LuasPermukaan(self, panjang, lebar, tinggi):
        self.panjang = panjang
        self.lebar = lebar
        self.tinggi = tinggi
        self.luas = 2 * ((self.panjang * self.lebar) + (self.lebar * self.tinggi) + (self.panjang * self.tinggi))
        return self.luas