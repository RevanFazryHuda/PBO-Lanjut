class segitiga:
    def __init__ (self):
        self._alas = None
        self._tinggi = None
    
    @property    
    def alas(self):
        return self.alas
    
    @alas.setter
    def alas(self, value):
        self._alas = value
        
    @property    
    def tinggi(self):
        return self.tinggi
    
    @tinggi.setter
    def tinggi(self, value):
        self._tinggi = value        
        
    def luas(self):
        return 0.5 * self._alas * self._tinggi
    
S = segitiga()
t = input('Masukkan nilai tinggi : ')
a = input('Masukkan nilai alas : ')
S.alas = int(a)
S.tinggi = int(t)
L = S.luas()
print('Alas\t: ',a)
print('Tinggi\t: ',t)
print('Luas\t: ',L)