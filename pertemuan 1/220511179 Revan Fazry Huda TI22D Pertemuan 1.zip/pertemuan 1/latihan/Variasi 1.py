import os

class mahasiswa:
    def __init__(self, nama, nim) :
        self.nama = nama
        self.nim = nim
        
    def info(self):
        print(f'nama\t: {self.nama}\nnim\t: {self.nim}')
        

mhs = mahasiswa('Ucup', '20319423')

os.system('cls')
mhs.info()