import json
import tkinter as tk
from tkinter import ttk, messagebox, BOTH, END, YES
from ttkthemes import ThemedTk
from Transaksi import *
import os
from tkcalendar import DateEntry

os.system('cls')
class FrmTransaksi:
    
    def __init__(self, parent, title, update_main_window):
        self.parent = parent       
        self.parent.geometry("800x600")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = None
        self.aturKomponen()
        self.onReload()
        self.parent.bind('<Return>', self.onCari)
        self.update_main_window = update_main_window             
        
    def aturKomponen(self):
        mainFrame = ttk.Frame(self.parent, padding=20)
        mainFrame.pack(fill=BOTH, expand=YES)
        
        # Label
        ttk.Label(mainFrame, text='Kode Transaksi:').grid(row=0, column=0,
            sticky=tk.W, padx=5, pady=5)
        ttk.Label(mainFrame, text='Nama Konsumen:').grid(row=1, column=0,
            sticky=tk.W, padx=5, pady=5)
        ttk.Label(mainFrame, text='Nama Obat:').grid(row=2, column=0,
            sticky=tk.W, padx=5, pady=5)
        ttk.Label(mainFrame, text='Tanggal Transaksi:').grid(row=3, column=0,
            sticky=tk.W, padx=5, pady=5)
        ttk.Label(mainFrame, text='Jumlah:').grid(row=4, column=0,
            sticky=tk.W, padx=5, pady=5)
        ttk.Label(mainFrame, text='Total Harga:').grid(row=5, column=0,
            sticky=tk.W, padx=5, pady=5)
        
        # Textbox
        self.txtKodeTransaksi = ttk.Entry(mainFrame) 
        self.txtKodeTransaksi.grid(row=0, column=1, padx=5, pady=5) 
        
        self.txtNamaKonsumen = ttk.Entry(mainFrame) 
        self.txtNamaKonsumen.grid(row=1, column=1, padx=5, pady=5) 
        
        self.txtNamaObat = ttk.Entry(mainFrame) 
        self.txtNamaObat.grid(row=2, column=1, padx=5, pady=5) 
        
        self.txtTanggalTransaksi = DateEntry(mainFrame, width = 18, date_pattern='y-mm-dd') 
        self.txtTanggalTransaksi.grid(row=3, column=1, padx=5, pady=5) 

        self.txtJumlah = ttk.Entry(mainFrame) 
        self.txtJumlah.grid(row=4, column=1, padx=5, pady=5) 

        self.txtTotalHarga = ttk.Entry(mainFrame) 
        self.txtTotalHarga.grid(row=5, column=1, padx=5, pady=5) 
        
        # Button
        self.btnSimpan = ttk.Button(mainFrame, text='Simpan', command=self.onSimpan, width=10)
        self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)
        self.btnClear = ttk.Button(mainFrame, text='Clear', command=self.onClear, width=10)
        self.btnClear.grid(row=1, column=3, padx=5, pady=5)
        self.btnHapus = ttk.Button(mainFrame, text='Hapus', command=self.onDelete, width=10)
        self.btnHapus.grid(row=2, column=3, padx=5, pady=5)
        self.btnCari = ttk.Button(mainFrame, text='Cari', command=self.onCari, width=10)
        self.btnCari.grid(row=3, column=3, padx=5, pady=5)        

        # define columns
        columns = ('id_transaksi', 'kode_transaksi', 'nama_konsumen', 'nama_obat', 'tanggal_transaksi', 'jumlah', 'total_harga')

        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('id_transaksi', text='ID Transaksi')
        self.tree.column('id_transaksi', width="100")
        self.tree.heading('kode_transaksi', text='Kode Transaksi')
        self.tree.column('kode_transaksi', width="105")
        self.tree.heading('nama_konsumen', text='Nama Konsumen')
        self.tree.column('nama_konsumen', width="120")
        self.tree.heading('nama_obat', text='Nama Obat')
        self.tree.column('nama_obat', width="120")
        self.tree.heading('tanggal_transaksi', text='Tanggal Transaksi')
        self.tree.column('tanggal_transaksi', width="100")
        self.tree.heading('jumlah', text='Jumlah')
        self.tree.column('jumlah', width="60")
        self.tree.heading('total_harga', text='Total Harga')
        self.tree.column('total_harga', width="90")
        
        # set tree position
        self.tree.place(x=0, y=280)

    def onClear(self, event=None):
        self.txtKodeTransaksi.delete(0,END)
        self.txtKodeTransaksi.insert(END,"")
        self.txtNamaKonsumen.delete(0,END)
        self.txtNamaKonsumen.insert(END,"")       
        self.txtNamaObat.delete(0,END)
        self.txtNamaObat.insert(END,"")       
        self.txtTanggalTransaksi.delete(0,END)
        self.txtTanggalTransaksi.insert(END,"")
        self.txtJumlah.delete(0,END)
        self.txtJumlah.insert(END,"")
        self.txtTotalHarga.delete(0,END)
        self.txtTotalHarga.insert(END,"")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data transaksi
        transaksi = Transaksi()
        result = transaksi.getAllData()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["id_transaksi"], d["kode_transaksi"], d["nama_konsumen"], d["nama_obat"], d["tanggal_transaksi"], d["jumlah"], d["total_harga"]))
    
    def onCari(self, event=None):
        kode_transaksi = self.txtKodeTransaksi.get()
        transaksi = Transaksi()
        a = transaksi.getByKodeTransaksi(kode_transaksi)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
        
        
    def TampilkanData(self, event=None):
        kode_transaksi = self.txtKodeTransaksi.get()
        transaksi = Transaksi()
        res = transaksi.getByKodeTransaksi(kode_transaksi)
        self.txtNamaKonsumen.delete(0,END)
        self.txtNamaKonsumen.insert(END,transaksi.nama_konsumen)
        self.txtNamaObat.delete(0,END)
        self.txtNamaObat.insert(END,transaksi.nama_obat)
        self.txtTanggalTransaksi.delete(0,END)
        self.txtTanggalTransaksi.insert(END,transaksi.tanggal_transaksi)
        self.txtJumlah.delete(0,END)
        self.txtJumlah.insert(END,transaksi.jumlah)
        self.txtTotalHarga.delete(0,END)
        self.txtTotalHarga.insert(END,transaksi.total_harga)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from textbox
        kode_transaksi = self.txtKodeTransaksi.get()
        nama_konsumen = self.txtNamaKonsumen.get()
        nama_obat = self.txtNamaObat.get()
        tanggal_transaksi = self.txtTanggalTransaksi.get()
        jumlah = self.txtJumlah.get()
        total_harga = self.txtTotalHarga.get()
        
        # create new Object
        transaksi = Transaksi()
        
        # set the attributes
        transaksi.kode_transaksi = kode_transaksi
        transaksi.nama_konsumen = nama_konsumen
        transaksi.nama_obat = nama_obat
        transaksi.tanggal_transaksi = tanggal_transaksi
        transaksi.jumlah = jumlah
        transaksi.total_harga = total_harga
        
        if(self.ditemukan==False):
            # save the record
            res = transaksi.simpan()
        else:
            # update the record
            res = transaksi.updateByKodeTransaksi(kode_transaksi)
        
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        #clear the form input
        self.onClear()

    def onDelete(self, event=None):
        kode_transaksi = self.txtKodeTransaksi.get()
        transaksi = Transaksi()
        transaksi.kode_transaksi = kode_transaksi
        if(self.ditemukan==True):
            res = transaksi.deleteByKodeTransaksi(kode_transaksi)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()


if __name__ == '__main__':
    def update_main_window():
        pass
    
    root2 = ThemedTk(theme='adapta')
    aplikasi = FrmTransaksi(root2, "Aplikasi Data Transaksi", update_main_window)
    root2.mainloop()