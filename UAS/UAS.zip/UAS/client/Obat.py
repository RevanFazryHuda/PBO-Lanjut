import requests
import json

class Obat:

    def __init__(self):
        self.__id = None
        self.__kode_obat = None
        self.__nama_obat = None
        self.__harga = None
        self.__stok = None
        self.__url = "http://localhost/webapi/obat_api.php"

    @property
    def id(self):
        return self.__id

    @property
    def kode_obat(self):
        return self.__kode_obat

    @kode_obat.setter
    def kode_obat(self, value):
        self.__kode_obat = value

    @property
    def nama_obat(self):
        return self.__nama_obat

    @nama_obat.setter
    def nama_obat(self, value):
        self.__nama_obat = value

    @property
    def harga(self):
        return self.__harga

    @harga.setter
    def harga(self, value):
        self.__harga = value

    @property
    def stok(self):
        return self.__stok

    @stok.setter
    def stok(self, value):
        self.__stok = value
        
    def getByKodeObat(self, kode_obat):
        url = self.__url + "?kode_obat=" + kode_obat
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        if data:
            self.__id = data[0]["id"]
            self.__kode_obat = data[0]["kode_obat"]
            self.__nama_obat = data[0]["nama_obat"]
            self.__harga = data[0]["harga"]
            self.__stok = data[0]["stok"]
        return data

    def simpan(self):
        payload = {
            "kode_obat": self.__kode_obat,
            "nama_obat": self.__nama_obat,
            "harga": self.__harga,
            "stok": self.__stok
        }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    
    def updateByKodeObat(self, kode_obat):
        url = self.__url + "?kode_obat=" + kode_obat
        payload = {
            "kode_obat": self.__kode_obat,
            "nama_obat": self.__nama_obat,
            "harga": self.__harga,
            "stok": self.__stok
        }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    
    def getAllData(self):
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    
    def deleteByKodeObat(self, kode_obat):
        url = f"{self.__url}?kode_obat={kode_obat}"
        headers = {'Content-Type': 'application/json'}
        payload = {}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
