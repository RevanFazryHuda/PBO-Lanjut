import requests
import json

class Transaksi:

    def __init__(self):
        self.__id_transaksi = None
        self.__kode_transaksi = None
        self.__nama_konsumen = None
        self.__nama_obat = None
        self.__tanggal_transaksi = None
        self.__jumlah = None
        self.__total_harga = None
        self.__url = "http://localhost/webapi/transaksi_api.php"

    @property
    def id_transaksi(self):
        return self.__id_transaksi

    @property
    def kode_transaksi(self):
        return self.__kode_transaksi

    @kode_transaksi.setter
    def kode_transaksi(self, value):
        self.__kode_transaksi = value

    @property
    def nama_konsumen(self):
        return self.__nama_konsumen

    @nama_konsumen.setter
    def nama_konsumen(self, value):
        self.__nama_konsumen = value

    @property
    def nama_obat(self):
        return self.__nama_obat

    @nama_obat.setter
    def nama_obat(self, value):
        self.__nama_obat = value

    @property
    def tanggal_transaksi(self):
        return self.__tanggal_transaksi

    @tanggal_transaksi.setter
    def tanggal_transaksi(self, value):
        self.__tanggal_transaksi = value

    @property
    def jumlah(self):
        return self.__jumlah

    @jumlah.setter
    def jumlah(self, value):
        self.__jumlah = value

    @property
    def total_harga(self):
        return self.__total_harga

    @total_harga.setter
    def total_harga(self, value):
        self.__total_harga = value
        
    def getByKodeTransaksi(self, kode_transaksi):
        url = self.__url + "?kode_transaksi=" + kode_transaksi
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        if data:
            self.__id_transaksi = data[0]["id_transaksi"]
            self.__kode_transaksi = data[0]["kode_transaksi"]
            self.__nama_konsumen = data[0]["nama_konsumen"]
            self.__nama_obat = data[0]["nama_obat"]
            self.__tanggal_transaksi = data[0]["tanggal_transaksi"]
            self.__jumlah = data[0]["jumlah"]
            self.__total_harga = data[0]["total_harga"]
        return data

    def simpan(self):
        payload = {
            "kode_transaksi": self.__kode_transaksi,
            "nama_konsumen": self.__nama_konsumen,
            "nama_obat": self.__nama_obat,
            "tanggal_transaksi": self.__tanggal_transaksi,
            "jumlah": self.__jumlah,
            "total_harga": self.__total_harga
        }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    
    def updateByKodeTransaksi(self, kode_transaksi):
        url = self.__url + "?kode_transaksi=" + kode_transaksi
        payload = {
            "kode_transaksi": self.__kode_transaksi,
            "nama_konsumen": self.__nama_konsumen,
            "nama_obat": self.__nama_obat,
            "tanggal_transaksi": self.__tanggal_transaksi,
            "jumlah": self.__jumlah,
            "total_harga": self.__total_harga
        }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    
    def getAllData(self):
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    
    def deleteByKodeTransaksi(self, kode_transaksi):
        url = f"{self.__url}?kode_transaksi={kode_transaksi}"
        headers = {'Content-Type': 'application/json'}
        payload = {}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
