import tkinter as tk
from tkinter import ttk , messagebox, NONE
from ttkthemes import ThemedTk
import requests
import json
import os

os.system('cls')
class Login:
    def __init__(self, parent, title, update_main_window):
        self.parent = parent
        self.parent.title(title)
        self.parent.geometry("250x170")
        self.parent.bind('<Return>', self.login)
        self.update_main_window = update_main_window 

        self.usernamelabel = ttk.Label(parent, text="Username")
        self.usernamelabel.pack()

        self.usernameentry = ttk.Entry(parent)
        self.usernameentry.pack()

        self.password_label = ttk.Label(parent, text="Password")
        self.password_label.pack()

        self.password_entry = ttk.Entry(parent, show='*')
        self.password_entry.pack()

        self.login_button = ttk.Button(parent, text="Login", command=self.login)
        self.login_button.pack(pady=10)

    def login(self, event = NONE):
        username = self.usernameentry.get()
        password = self.password_entry.get()

        payload = {'username': username, 'password': password}
        response = requests.post("http://localhost/webapi/users_api.php", data=payload)

        result = json.loads(response.text)
        if result['status'] == 'success':
            messagebox.showinfo("Success", result['message'])
            self.parent.destroy()
            self.open_menu_utama()
        else:
            messagebox.showerror("Error", result['message'])

    def open_menu_utama(self):
        import dashboard
        dashboard.Dashboard(tk.Tk())

if __name__ == "__main__":
    def update_main_window(result):
        print(result)
    
    root = ThemedTk(theme='Adapta')
    app = Login(root,'Aplikasi Login' ,update_main_window)
    root.mainloop()