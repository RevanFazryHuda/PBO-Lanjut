import json
import tkinter as tk
from tkinter import ttk, messagebox, BOTH, END, YES
from ttkthemes import ThemedTk
from Obat import *  # Ensure you have an Obat class defined in a module named Obat
import os

os.system('cls')

class FrmObat:
    
    def __init__(self, parent, title, update_main_window):
        self.parent = parent       
        self.parent.geometry("500x500")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = None
        self.aturKomponen()
        self.onReload()
        self.parent.bind('<Return>', self.onCari)
        self.update_main_window = update_main_window             
        
    def aturKomponen(self):
        mainFrame = ttk.Frame(self.parent, padding=20)
        mainFrame.pack(fill=BOTH, expand=YES)
        
        # Label
        ttk.Label(mainFrame, text='Kode Obat:').grid(row=0, column=0,
            sticky=tk.W, padx=5, pady=5)
        ttk.Label(mainFrame, text='Nama Obat:').grid(row=1, column=0,
            sticky=tk.W, padx=5, pady=5)
        ttk.Label(mainFrame, text='Harga:').grid(row=2, column=0,
            sticky=tk.W, padx=5, pady=5)
        ttk.Label(mainFrame, text='Stok:').grid(row=3, column=0,
            sticky=tk.W, padx=5, pady=5)
        
        # Textbox
        self.txtKodeObat = ttk.Entry(mainFrame) 
        self.txtKodeObat.grid(row=0, column=1, padx=5, pady=5) 
        
        self.txtNamaObat = ttk.Entry(mainFrame) 
        self.txtNamaObat.grid(row=1, column=1, padx=5, pady=5) 
        
        self.txtHarga = ttk.Entry(mainFrame) 
        self.txtHarga.grid(row=2, column=1, padx=5, pady=5) 

        self.txtStok = ttk.Entry(mainFrame) 
        self.txtStok.grid(row=3, column=1, padx=5, pady=5) 
        
        # Button
        self.btnSimpan = ttk.Button(mainFrame, text='Simpan', command=self.onSimpan, width=10)
        self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)
        self.btnClear = ttk.Button(mainFrame, text='Clear', command=self.onClear, width=10)
        self.btnClear.grid(row=1, column=3, padx=5, pady=5)
        self.btnHapus = ttk.Button(mainFrame, text='Hapus', command=self.onDelete, width=10)
        self.btnHapus.grid(row=2, column=3, padx=5, pady=5)
        self.btnCari = ttk.Button(mainFrame, text='Cari', command=self.onCari, width=10)
        self.btnCari.grid(row=3, column=3, padx=5, pady=5)        

        # Define columns (excluding 'id_obat')
        columns = ('kode_obat', 'nama_obat', 'harga', 'stok')

        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # Define headings
        self.tree.heading('kode_obat', text='Kode Obat')
        self.tree.column('kode_obat', width="105")
        self.tree.heading('nama_obat', text='Nama Obat')
        self.tree.column('nama_obat', width="120")
        self.tree.heading('harga', text='Harga')
        self.tree.column('harga', width="100")
        self.tree.heading('stok', text='Stok')
        self.tree.column('stok', width="60")
        
        # Set tree position
        self.tree.place(x=0, y=200)

    def onClear(self, event=None):
        self.txtKodeObat.delete(0, END)
        self.txtKodeObat.insert(END, "")
        self.txtNamaObat.delete(0, END)
        self.txtNamaObat.insert(END, "")       
        self.txtHarga.delete(0, END)
        self.txtHarga.insert(END, "")       
        self.txtStok.delete(0, END)
        self.txtStok.insert(END, "")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # Get data obat
        obat = Obat()
        result = obat.getAllData()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["kode_obat"], d["nama_obat"], d["harga"], d["stok"]))
    
    def onCari(self, event=None):
        kode_obat = self.txtKodeObat.get()
        obat = Obat()
        a = obat.getByKodeObat(kode_obat)
        if len(a) > 0:
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
        
    def TampilkanData(self, event=None):
        kode_obat = self.txtKodeObat.get()
        obat = Obat()
        res = obat.getByKodeObat(kode_obat)
        self.txtNamaObat.delete(0, END)
        self.txtNamaObat.insert(END, obat.nama_obat)
        self.txtHarga.delete(0, END)
        self.txtHarga.insert(END, obat.harga)
        self.txtStok.delete(0, END)
        self.txtStok.insert(END, obat.stok)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # Get the data from textbox
        kode_obat = self.txtKodeObat.get()
        nama_obat = self.txtNamaObat.get()
        harga = self.txtHarga.get()
        stok = self.txtStok.get()
        
        # Create new Object
        obat = Obat()
        
        # Set the attributes
        obat.kode_obat = kode_obat
        obat.nama_obat = nama_obat
        obat.harga = harga
        obat.stok = stok
        
        if self.ditemukan == False:
            # Save the record
            res = obat.simpan()
        else:
            # Update the record
            res = obat.updateByKodeObat(kode_obat)
        
        # Read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # Display json data in messagebox
        messagebox.showinfo("showinfo", status + ', ' + msg)
        
        # Clear the form input
        self.onClear()

    def onDelete(self, event=None):
        kode_obat = self.txtKodeObat.get()
        obat = Obat()
        obat.kode_obat = kode_obat
        if self.ditemukan == True:
            res = obat.deleteByKodeObat(kode_obat)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # Read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # Display json data in messagebox
        messagebox.showinfo("showinfo", status + ', ' + msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # Close the application
        self.parent.destroy()


if __name__ == '__main__':
    def update_main_window():
        pass
    
    root2 = ThemedTk(theme='adapta')
    aplikasi = FrmObat(root2, "Aplikasi Data Obat", update_main_window)
    root2.mainloop()
