import tkinter as tk
from tkinter import Menu, ttk
from ttkthemes import ThemedTk
from Frm_user import Login
from FrmTransaksi import FrmTransaksi
from FrmObat import FrmObat
import os

class Dashboard:
    def __init__(self, root):
        # root window
        self.root = root
        self.root.title('Menu Demo')
        self.root.geometry("803x527")
        self.__data = None
        self.__level = None
        self.BeriGambar()

        self.top_frame = ttk.Frame(root)
        self.top_frame.pack(expand=True, fill="both")
        # create a menubar
        self.menubar = tk.Menu(self.root)
        self.root.config(menu=self.menubar)

        # create menus
        self.file_menu = tk.Menu(self.menubar, tearoff=0) 
        self.admin_menu = tk.Menu(self.menubar, tearoff=0)               

        # add menu items to File menu
        self.file_menu.add_command(label='Exit', command=self.root.destroy)

        # add menu items to menu Admin
        self.admin_menu.add_command(label='Detail Transaksi', command=lambda: self.new_window("Detail Transaksi", FrmTransaksi))
        self.admin_menu.add_command(label='Daftar Obat', command=lambda: self.new_window("Daftar Obat", FrmObat))


        # add menus to the menubar
        self.menubar.add_cascade(label="File", menu=self.file_menu)
        self.menubar.add_cascade(label="Admin", menu=self.admin_menu)    
        
    def BeriGambar(self):
        self.image = tk.PhotoImage(file='C:/Users/Revan/OneDrive/Documents/VSCode/PBO_Lanjut/UAS/client/toko.png')
        self.image_label = ttk.Label(self.root, image=self.image)
        self.image_label.pack(expand=True, fill='both')    

    def new_window(self, title, _class):
        new = tk.Toplevel(self.root)
        new.transient(self.root)
        new.grab_set()
        _class(new, title, self.update_main_window)

    def update_main_window(self, data):
        # Method to receive data from child windows
        self.__data = data
        level = self.__data[0]
        loginvalid = self.__data[1]

        if loginvalid:
            if level == 'admin':
                self.menubar.add_cascade(label="Admin", menu=self.admin_menu)
                self.__level = 'admin'  # Store current level
            else:
                pass  # Handle other levels as needed

            # Replace 'Login' with 'Logout'
            self.file_menu.delete('Login')
            self.file_menu.add_command(label='Logout', command=self.Logout)

    def Logout(self):
        index = self.file_menu.index('Logout')
        self.file_menu.delete(index)
        self.file_menu.add_command(label='Login', command=lambda: self.new_window("Log Me In", Login ))
        self.remove_all_menus()
        
        if self.__level == 'admin':
            self.menubar.delete('Admin')
            self.__level = None

    def remove_all_menus(self):
        for label in self.__level:
            index = self.menubar.index(label)
            if index is not None:
             self.menubar.delete(index)


if __name__ == "__main__":
    os.system('cls')
    root = ThemedTk(theme='Adapta')
    menu_app = Dashboard(root)
    root.mainloop()