<?php
require_once 'database.php';

class Obat
{
    private $db;
    private $table = 'obat';
    public $kode_obat = "";
    public $nama_obat = "";
    public $harga = 0.0;
    public $stok = 0;

    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }

    public function get_all()
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }

    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);
        return $result_set;
    }

    public function get_by_kode_obat(string $kode_obat)
    {
        $query = "SELECT * FROM $this->table WHERE kode_obat = '$kode_obat'";
        $result_set = $this->db->query($query);
        return $result_set;
    }

    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`kode_obat`, `nama_obat`, `harga`, `stok`) VALUES ('$this->kode_obat', '$this->nama_obat', $this->harga, $this->stok)";
        $this->db->query($query);
        return $this->db->insert_id();
    }

    public function update(int $id): int
    {
        $query = "UPDATE $this->table SET `kode_obat` = '$this->kode_obat', `nama_obat` = '$this->nama_obat', `harga` = $this->harga, `stok` = $this->stok WHERE id = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }

    public function update_by_kode_obat($kode_obat): int
    {
        $query = "UPDATE $this->table SET `nama_obat` = '$this->nama_obat', `harga` = $this->harga, `stok` = $this->stok WHERE kode_obat = '$kode_obat'";
        $this->db->query($query);
        return $this->db->affected_rows();
    }

    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE id = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }

    public function delete_by_kode_obat($kode_obat): int
    {
        $query = "DELETE FROM $this->table WHERE kode_obat = '$kode_obat'";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>
