<?php
require_once 'database.php';
require_once 'Transaksi.php';

$db = new MySQLDatabase();
$transaksi = new Transaksi($db);
$id = 0;
$kode_transaksi = "";

// Check the HTTP request method
$method = $_SERVER['REQUEST_METHOD'];

// Handle the different HTTP methods
switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
        }
        if (isset($_GET['kode_transaksi'])) {
            $kode_transaksi = $_GET['kode_transaksi'];
        }

        if ($id > 0) {
            $result = $transaksi->get_by_id($id);
        } elseif (!empty($kode_transaksi)) {
            $result = $transaksi->get_by_kode_transaksi($kode_transaksi);
        } else {
            $result = $transaksi->get_all();
        }

        $transactions = array();
        while ($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }
        header('Content-Type: application/json');
        echo json_encode($transactions);
        break;

    case 'POST':
        // Add a new transaksi 
        $transaksi->kode_transaksi = $_POST['kode_transaksi'];
        $transaksi->nama_konsumen = $_POST['nama_konsumen'];
        $transaksi->nama_obat = $_POST['nama_obat'];
        $transaksi->tanggal_transaksi = $_POST['tanggal_transaksi'];
        $transaksi->jumlah = intval($_POST['jumlah']);
        $transaksi->total_harga = floatval($_POST['total_harga']);
        $transaksi->insert();

        $a = $db->affected_rows();

        if ($a > 0) {
            $data['status'] = 'success';
            $data['message'] = 'Salamat telah berhasil.';
        } else {
            $data['status'] = 'failed';
            $data['message'] = 'yah gagal simpan.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;

    case 'PUT':
        // Update an existing transaksi
        $_PUT = [];
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
        }
        if (isset($_GET['kode_transaksi'])) {
            $kode_transaksi = $_GET['kode_transaksi'];
        }
        parse_str(file_get_contents("php://input"), $_PUT);
        $transaksi->kode_transaksi = $_PUT['kode_transaksi'];
        $transaksi->nama_konsumen = $_PUT['nama_konsumen'];
        $transaksi->nama_obat = $_PUT['nama_obat'];
        $transaksi->tanggal_transaksi = $_PUT['tanggal_transaksi'];
        $transaksi->jumlah = intval($_PUT['jumlah']);
        $transaksi->total_harga = floatval($_PUT['total_harga']);

        if ($id > 0) {
            $transaksi->update($id);
        } elseif (!empty($kode_transaksi)) {
            $transaksi->update_by_kode_transaksi($kode_transaksi);
        } else {
            // Handle error case where neither id nor kode_transaksi is provided
        }

        $a = $db->affected_rows();

        if ($a > 0) {
            $data['status'] = 'success';
            $data['message'] = 'Salamat telah berhasil.';
        } else {
            $data['status'] = 'failed';
            $data['message'] = 'yah gagal update.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;

    case 'DELETE':
        // Delete a transaksi
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
        }
        if (isset($_GET['kode_transaksi'])) {
            $kode_transaksi = $_GET['kode_transaksi'];
        }

        if ($id > 0) {
            $transaksi->delete($id);
        } elseif (!empty($kode_transaksi)) {
            $transaksi->delete_by_kode_transaksi($kode_transaksi);
        } else {
            // Handle error case where neither id nor kode_transaksi is provided
        }

        $a = $db->affected_rows();

        if ($a > 0) {
            $data['status'] = 'success';
            $data['message'] = 'sudah kehapus.';
        } else {
            $data['status'] = 'failed';
            $data['message'] = 'yah gagal delete.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;

    default:
        header("HTTP/1.0 405 Method Not Allowed");
        break;
}

$db->close();
?>
