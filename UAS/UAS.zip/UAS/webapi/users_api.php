<?php
require_once 'database.php';

$db = new MySQLDatabase();
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

$query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
$result_set = $db->query($query);
$user = $result_set->fetch_assoc();

$response = [];
if ($user) {
    $response['status'] = 'success';
    $response['message'] = 'Login Berhasil';
} else {
    $response['status'] = 'failed';
    $response['message'] = 'username atau password salah';
}

header('Content-Type: application/json');
echo json_encode($response);

$db->close();
?>
