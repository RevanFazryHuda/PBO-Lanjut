<?php
require_once 'database.php';

class Transaksi
{
    private $db;
    private $table = 'transaksi';
    public $kode_transaksi = "";
    public $nama_konsumen = "";
    public $nama_obat = "";
    public $tanggal_transaksi = "";
    public $jumlah = 0;
    public $total_harga = 0.0;

    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }

    public function get_all()
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }

    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id_transaksi = $id";
        $result_set = $this->db->query($query);
        return $result_set;
    }

    public function get_by_kode_transaksi(string $kode_transaksi)
    {
        $query = "SELECT * FROM $this->table WHERE kode_transaksi = '$kode_transaksi'";
        $result_set = $this->db->query($query);
        return $result_set;
    }

    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`kode_transaksi`, `nama_konsumen`, `nama_obat`, `tanggal_transaksi`, `jumlah`, `total_harga`) VALUES ('$this->kode_transaksi', '$this->nama_konsumen', '$this->nama_obat', '$this->tanggal_transaksi', $this->jumlah, $this->total_harga)";
        $this->db->query($query);
        return $this->db->insert_id();
    }

    public function update(int $id): int
    {
        $query = "UPDATE $this->table SET `kode_transaksi` = '$this->kode_transaksi', `nama_konsumen` = '$this->nama_konsumen', `nama_obat` = '$this->nama_obat', `tanggal_transaksi` = '$this->tanggal_transaksi', `jumlah` = $this->jumlah, `total_harga` = $this->total_harga WHERE id_transaksi = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }

    public function update_by_kode_transaksi($kode_transaksi): int
    {
        $query = "UPDATE $this->table SET `nama_konsumen` = '$this->nama_konsumen', `nama_obat` = '$this->nama_obat', `tanggal_transaksi` = '$this->tanggal_transaksi', `jumlah` = $this->jumlah, `total_harga` = $this->total_harga WHERE kode_transaksi = '$kode_transaksi'";
        $this->db->query($query);
        return $this->db->affected_rows();
    }

    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE id_transaksi = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }

    public function delete_by_kode_transaksi($kode_transaksi): int
    {
        $query = "DELETE FROM $this->table WHERE kode_transaksi = '$kode_transaksi'";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>
