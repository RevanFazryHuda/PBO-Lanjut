<?php
require_once 'database.php';
require_once 'Obat.php';

$db = new MySQLDatabase();
$obat = new Obat($db);
$id = 0;
$kode_obat = "";

// Check the HTTP request method
$method = $_SERVER['REQUEST_METHOD'];

// Handle the different HTTP methods
switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
        }
        if (isset($_GET['kode_obat'])) {
            $kode_obat = $_GET['kode_obat'];
        }

        if ($id > 0) {
            $result = $obat->get_by_id($id);
        } elseif (!empty($kode_obat)) {
            $result = $obat->get_by_kode_obat($kode_obat);
        } else {
            $result = $obat->get_all();
        }

        $medicines = array();
        while ($row = $result->fetch_assoc()) {
            $medicines[] = $row;
        }
        header('Content-Type: application/json');
        echo json_encode($medicines);
        break;

    case 'POST':
        // Add a new obat 
        $obat->kode_obat = $_POST['kode_obat'];
        $obat->nama_obat = $_POST['nama_obat'];
        $obat->harga = floatval($_POST['harga']);
        $obat->stok = intval($_POST['stok']);
        $obat->insert();

        $a = $db->affected_rows();

        if ($a > 0) {
            $data['status'] = 'success';
            $data['message'] = 'Salamat telah berhasil.';
        } else {
            $data['status'] = 'failed';
            $data['message'] = 'yah gagal simpan.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;

    case 'PUT':
        // Update an existing obat
        $_PUT = [];
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
        }
        if (isset($_GET['kode_obat'])) {
            $kode_obat = $_GET['kode_obat'];
        }
        parse_str(file_get_contents("php://input"), $_PUT);
        $obat->kode_obat = $_PUT['kode_obat'];
        $obat->nama_obat = $_PUT['nama_obat'];
        $obat->harga = floatval($_PUT['harga']);
        $obat->stok = intval($_PUT['stok']);

        if ($id > 0) {
            $obat->update($id);
        } elseif (!empty($kode_obat)) {
            $obat->update_by_kode_obat($kode_obat);
        } else {
            // Handle error case where neither id nor kode_obat is provided
        }

        $a = $db->affected_rows();

        if ($a > 0) {
            $data['status'] = 'success';
            $data['message'] = 'Salamat telah berhasil.';
        } else {
            $data['status'] = 'failed';
            $data['message'] = 'yah gagal update.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;

    case 'DELETE':
        // Delete a obat
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
        }
        if (isset($_GET['kode_obat'])) {
            $kode_obat = $_GET['kode_obat'];
        }

        if ($id > 0) {
            $obat->delete($id);
        } elseif (!empty($kode_obat)) {
            $obat->delete_by_kode_obat($kode_obat);
        } else {
            // Handle error case where neither id nor kode_obat is provided
        }

        $a = $db->affected_rows();

        if ($a > 0) {
            $data['status'] = 'success';
            $data['message'] = 'sudah kehapus.';
        } else {
            $data['status'] = 'failed';
            $data['message'] = 'yah gagal delete.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;

    default:
        header("HTTP/1.0 405 Method Not Allowed");
        break;
}

$db->close();
?>
